# threejs-webflow
Setup to connect with Webflow and work with Three.js.


Step 1: Clone this repository.
Step 2: Console - npm install.
Step 3: Console - npm run dev.
Localhost its Live now 
Step 4: Install ThreeJs - console - npm install three.

